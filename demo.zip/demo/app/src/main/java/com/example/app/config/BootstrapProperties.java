package com.example.app.config;

import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;

@Order(-100)
@Configuration
public class BootstrapProperties implements EnvironmentAware {


    public static String url;
    public static String username;
    public static String password;
    public static String driverClassName;

    @Override
    public void setEnvironment(Environment environment) {
        getPropertiesValue(environment);
    }

    public void getPropertiesValue(Environment environment){
        RelaxedPropertyResolver propertyResolver = new RelaxedPropertyResolver(environment, "spring.");
        url=propertyResolver.getProperty("datasource.url");
        username=propertyResolver.getProperty("datasource.username");
        password=propertyResolver.getProperty("datasource.password");
        driverClassName=propertyResolver.getProperty("datasource.driverClassName");

    }

}
