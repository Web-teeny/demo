package com.example.app.config;

import com.example.app.utils.CrawlerThread;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.ArrayList;
import java.util.List;

/**
 * 定时任务  爬取数据
 * Created by Teeny on 2018/2/28.
 */

public class Scheduler {
    protected static final Logger logger = Logger.getLogger(Scheduler.class);


    //@Scheduled(cron="0 0 0 * * ?")
    public static void bookTasks() throws Exception {

        ArrayList<String> urlList = new ArrayList();
        for(int i = 0,prev = -1;i < 76;i++){
            int page = prev + 2;
            String url = "http://search.jd.com/Search?keyword=Python&enc=utf-8&qrst=1&rt=1&stop=1&book=y&vt=2&wq=Python&page=" + page + "&s=1&click=0";
            urlList.add(url);
            prev = page;

        }
        logger.info("===============================定时任务开始================================================");

        // 线程数量
        int threadCount = 0;
        if(urlList.size()>0){
            threadCount=urlList.size();
            // 用来让主线程等待threadCount个子线程执行完毕
            // CountDownLatch countDownLatch = new CountDownLatch(threadCount);
            // 启动threadCount个子线程
            for(int i = 0; i < threadCount; i++)
            {
                String  url= urlList.get(i);
                HttpClient client =  HttpClients.createDefault();

                Thread thread = new Thread(new CrawlerThread(client,url));
                thread.start();
            }
           /* try
            {
                // 主线程等待所有子线程执行完成，再向下执行
                countDownLatch.await();
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }*/
            //   logger.info("===============================定时任务结束================================================");
        }

    }

}
