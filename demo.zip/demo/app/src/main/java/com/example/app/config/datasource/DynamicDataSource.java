package com.example.app.config.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 *
 * @Description: 动态数据源 继承 AbstractRoutingDataSource
 * @date 2017/07/12
 *
 */
public class DynamicDataSource extends AbstractRoutingDataSource {

	@Override
	protected Object determineCurrentLookupKey() {

		return DynamicDataSourceContextHolder.getDataSourceType();
	}
	
}
