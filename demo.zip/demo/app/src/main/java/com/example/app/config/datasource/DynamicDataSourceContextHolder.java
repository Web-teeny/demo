package com.example.app.config.datasource;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @Description: 动态数据源工具类，单例模式，支持多线程。提供判断指定DataSrouce当前是否存在
 * @date 2017/07/12
 *
 */
public class DynamicDataSourceContextHolder {
	
	private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();
	public static List<String> dataSourceIds = new ArrayList<>();

	public static void setDataSourceType(String dataSourceType) {
		contextHolder.set(dataSourceType);
	}

	public static String getDataSourceType() {
		return contextHolder.get();
	}

	public static void clearDataSourceType() {
		contextHolder.remove();
	}
	
	public static boolean containsDataSource(String dataSourceId){
		return dataSourceIds.contains(dataSourceId);
	}
}
