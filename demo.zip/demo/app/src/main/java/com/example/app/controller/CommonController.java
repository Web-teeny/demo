package com.example.app.controller;

import com.example.app.domain.TableResult;
import com.example.app.service.CommonService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.sf.json.JSONSerializer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Teeny on 2018/2/27.
 */
@RestController
@RequestMapping(value = "/common/")
@Api(value = "common", description = "公共的请求查询")
public class CommonController {

    private static Log logger = LogFactory.getLog(CommonController.class);

    @Autowired
    private CommonService commonservice;

    @GetMapping(value = "findList")
    @ResponseBody
    @ApiOperation(value = "查询列表", notes = "")
    @ApiResponses(value = {@ApiResponse(code = 500, message = "Server Error")})
    public List findList(@RequestParam Map<String, Object> map)throws Exception {
        List list=commonservice.findList(map.get("sid").toString(),map);
        return list;
    }

    @GetMapping(value = "findListPage")
    @ResponseBody
    @ApiOperation(value = "分页查询列表", notes = "")
    @ApiResponses(value = {@ApiResponse(code = 500, message = "Server Error")})
    public TableResult findListPage(@RequestParam Map<String, Object> map,int page,int rows)throws Exception {
        List list=commonservice.findListpage(map.get("sid").toString(),map,page,rows);
        return TableResult.create(list);
    }


}
