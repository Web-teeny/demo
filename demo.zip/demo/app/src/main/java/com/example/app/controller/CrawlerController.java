package com.example.app.controller;

import com.example.app.config.Scheduler;
import com.example.app.service.CommonService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Created by Teeny on 2018/2/28.
 */
@RestController
@RequestMapping(value = "/crawer/")
public class CrawlerController {

    private static Log logger = LogFactory.getLog(CrawlerController.class);

    @Autowired
    private CommonService commonservice;

    //private Scheduler scheduler;

    @GetMapping(value = "startCrawl")
    @ResponseBody
    public String startCrawl(@RequestParam Map<String, Object> map) {

        String msg = "{success:true,msg:\"开始爬虫！\"}";
        String url="http://search.jd.com/Search?keyword=Python&enc=utf-8&book=y&wq=Python&pvid=33xo9lni.p4a1qb";
        HttpClient client =  HttpClients.createDefault();

        try{

            //删除所有数据
            commonservice.delete("test.deleteBook",null);

            Scheduler.bookTasks();
           // List<JdModel> bookdatas= URLFecter.URLParser(client, url);

            //循环输出抓取的数据
            /*for (JdModel jd:bookdatas) {
                logger.info("bookID:"+jd.getBookID()+"\t"+"bookPrice:"+jd.getBookPrice()+"\t"+"bookName:"+jd.getBookName());
            }*/
            //将抓取的数据插入数据库
            //DBHandler.batchInsert(bookdatas);
        }catch (Exception e){
            msg = "{success:false,msg:\"失败\"}";
            e.printStackTrace();
        }

        return msg;
    }

}
