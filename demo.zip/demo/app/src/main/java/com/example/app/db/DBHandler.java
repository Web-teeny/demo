package com.example.app.db;

import com.example.app.model.JdModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 * Created by Teeny on 2018/2/28.
 */
public class DBHandler {

    //数据库操作方法
    public static void batchInsert(List<JdModel> bookdata) throws SQLException, ClassNotFoundException {

        Connection conn = DataSource.getConnection();

        if(conn == null){
            System.out.println("=====>>数据库连接失败======");
            return;
        }


        //删除全部
        /*Statement stmt = conn.createStatement();
        String sql = "delete from book";
        stmt.executeUpdate(sql);
        stmt.close();*/


        String sql = "insert into book(bookID, bookName, bookPrice) values (?,?,?)";

        conn.setAutoCommit(false);


        PreparedStatement pst = conn.prepareStatement(sql);

        int count = 0;
        for (int i = 0; i < bookdata.size(); i++) {
            pst.setString(1,bookdata.get(i).getBookID());
            pst.setString(2,bookdata.get(i).getBookName());
            pst.setString(3,bookdata.get(i).getBookPrice());

            count++;
            pst.addBatch();

            if (count % 1000 == 100) {
                pst.executeBatch();
                count = 0;
            }
        }

        if(count != 0){
            pst.executeBatch();
        }

        conn.commit();

        pst.close();
        conn.close();

        System.out.println("执行数据库完毕！"+"成功插入数据："+bookdata.size()+"条");

    }
}
