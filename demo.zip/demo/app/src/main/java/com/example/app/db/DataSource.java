package com.example.app.db;

import com.example.app.config.BootstrapProperties;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by Teeny on 2018/2/28.
 */
public class DataSource {

    public static Connection getConnection() throws SQLException, ClassNotFoundException {

        Class.forName(BootstrapProperties.driverClassName);   //类加载方式

        Connection conn = null;
        conn = DriverManager.getConnection(BootstrapProperties.url, BootstrapProperties.username, BootstrapProperties.password);

        return conn;

    }
}
