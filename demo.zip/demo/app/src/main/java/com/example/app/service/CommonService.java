package com.example.app.service;

import com.example.app.dao.Commondao;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Teeny on 2018/2/27.
 */
@Service
public class CommonService {

    @Autowired
    private Commondao dao;

    public List findList(String statementId, Object parameter)throws Exception {
        return dao.findList(statementId,parameter);
    }

    public List findListpage(String statementId, Object parameter,int page,int rows)throws Exception {
        PageHelper.startPage(page, rows);
        return dao.findList(statementId,parameter);
    }

    @Transactional(value="txManager")
    public int update(String statementId, Object parameter) throws Exception{
        return  dao.update(statementId,parameter);
    }

    public Object add(String statementId, Object parameter) throws Exception{
        return  dao.add(statementId,parameter);
    }

    public Object delete(String statementId, Object parameter) throws Exception{
        return dao.delete(statementId,parameter);
    }

}
