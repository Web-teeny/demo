package com.example.app.utils;

import com.example.app.service.urlFecterService;
import org.apache.http.client.HttpClient;

/**
 * Created by Teeny on 2018/2/28.
 */
public class CrawlerThread implements Runnable{
    private String url;
    private HttpClient client;
    private urlFecterService urlFecter;

    public CrawlerThread(HttpClient client, String url)
    {
        this.client=client;
        this.url=url;
        this.urlFecter = new urlFecterService();
    }

    @Override
    public void run() {
        try {
            urlFecter.URLParser(this.client, this.url);
            Thread current = Thread.currentThread();
            System.out.println(this.url+"打印线程信息=="+current.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
