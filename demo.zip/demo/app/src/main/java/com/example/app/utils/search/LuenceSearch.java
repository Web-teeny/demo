package com.example.app.utils.search;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import com.example.app.model.JdModel;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.TermToBytesRefAttribute;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.IOContext;
import org.apache.lucene.store.RAMDirectory;
import org.wltea.analyzer.lucene.IKAnalyzer;

/**
 * Created by Teeny on 2018/3/1.
 */
public class LuenceSearch  {

    //索引位置
    public static final String indexDir ="F://medIndexText";


    private Directory dir; //存放索引的位置

    public static void main(String[] args)
    {
        //数据库取值--放入索引
        LuenceSearch luence = new LuenceSearch();
        luence.db();

        //查询本地索引
        String keyWord = "机器人";
        try {
            luence.search(keyWord);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    //获取IndexWriter实例
    private IndexWriter getWriter() throws Exception {
        SmartChineseAnalyzer analyzer = new SmartChineseAnalyzer();//使用中文分词器
        IndexWriterConfig config = new IndexWriterConfig(analyzer); //将标准分词器配到写索引的配置中
        IndexWriter writer = new IndexWriter(dir, config); //实例化写索引对象
        return writer;
    }

    //索引建立优化
    public void addIndex(JdModel book) throws Exception{
        
        dir = FSDirectory.open(Paths.get(indexDir));
        IndexWriter writer = getWriter();
        Document doc = new Document();
        doc.add(new TextField("desc", book.getBookName(), Field.Store.YES));
        writer.addDocument(doc); //添加文档
        writer.close(); //close了才真正写到文档中
    }

    public void search(String keyWord) throws IOException, ParseException {
        //IKAnalyzer analyzer = new IKAnalyzer();
        // 分词处理
        //List<String> words = cutKeyWord(keyWord, analyzer);

        long start = new Date().getTime();
        SmartChineseAnalyzer analyzer = new SmartChineseAnalyzer(); //使用中文分词器
        QueryParser parser = new QueryParser("desc", analyzer); //查询解析器
        Query query = parser.parse(keyWord); //通过解析要查询的String，获取查询对象

        IndexSearcher searcher = getIndexSearcher();
        TopDocs docs = searcher.search(query, 3000);
        long end = new Date().getTime();

        System.out.println("搜索用时：" + (end - start) + "ms");
        System.out.println("一共搜索到结果："+docs.totalHits+"条");
        //输出查询结果信息
        for(ScoreDoc scoreDoc:docs.scoreDocs){
            Document doc = searcher.doc(scoreDoc.doc);
            System.out.println(doc.get("desc"));
        }
    }

    public IndexSearcher getIndexSearcher() throws IOException {
        Directory dir = FSDirectory.open(Paths.get(indexDir)); //获取要查询的路径，也就是索引所在的位置
        IndexReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);
        return searcher;
    }

    public void db()
    {

        //驱动程序名
        String driver = "oracle.jdbc.driver.OracleDriver";
        //URL指向要访问的数据库名
        String url = "jdbc:oracle:thin:@//172.16.18.175:1521/csgic";
        //MySQL配置时的用户名
        String user = "ic";
        //MySQL配置时的密码
        String password = "ic";

        Connection conn = null;
        //结果集
        ResultSet rs = null;
        try {
            //加载驱动程序
            Class.forName(driver);
            //连接MySQL数据库
            conn = DriverManager.getConnection(url, user, password);

            Date start = new Date(System.currentTimeMillis());
            if (conn != null) {
                System.out.println("-----连接数据库-----");
                //statement用来执行SQL语句
                Statement statement = conn.createStatement();
                //要执行的SQL语句
                String sql = "select bookName from book t";
                rs = statement.executeQuery(sql);
                JdModel book = new JdModel();
                while(rs.next()) {
                    //选择name这列数据
                    book.setBookName(rs.getString("bookName"));
                    addIndex(book);
                }
                Date end = new Date(System.currentTimeMillis());
                System.out.println("建立索引用时：" + (end.getTime() - start.getTime()) + "ms");
            }
        } catch (Exception e) {

        } finally {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

}
